package com.example.lenovo.lab31;
import java.util.Map;
import java.util.Objects;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;


public abstract class CommonAdapter extends RecyclerView.Adapter<ViewHolder> {

    protected Context mContext;
    protected ArrayList<Map<String,Object>> mDatas;
    protected LayoutInflater mInflater;
    protected int mLayoutId;
    protected OnItemClickListener mOnItemClickListener;
    public CommonAdapter(Context context, int layoutId,ArrayList<Map<String,Object>> datas) {
        this.mContext = context;
        mInflater = LayoutInflater.from(context);
        this.mDatas = datas;
        this.mLayoutId = layoutId;
    }
    @Override
    public int getItemCount() {
        return mDatas.size();
    }
    //删除数据
    public void removeData(int positon){
        mDatas.remove(positon);
        notifyItemRemoved(positon);
        notifyDataSetChanged();
    }
    public abstract void convert(ViewHolder holder, Map<String,Object> t);
    //创建视图，并返回ViewHolder，
    @Override
    public ViewHolder onCreateViewHolder(final ViewGroup parent,int viewType) {
        ViewHolder viewHolder = ViewHolder.get(mContext,parent,mLayoutId);
        return viewHolder;
    }
    //绑定数据到正确的Item视图上
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        convert(holder, mDatas.get(position));
        if (mOnItemClickListener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mOnItemClickListener.onClick(holder.getAdapterPosition());
                }
            });
            holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    mOnItemClickListener.onLongClick(holder.getAdapterPosition());
                    return false;
                }
            });
        }
    }
    public void onDataChange(ArrayList<Map<String,Object>> data) {
        this.mDatas = data;
        this.notifyDataSetChanged();
    }
    public interface OnItemClickListener{
        void onClick(int position);
        void onLongClick(int position);
    }
    public void setOnItemClickListener(OnItemClickListener onItemClickListener){
        this.mOnItemClickListener=onItemClickListener;
    }

}
