package com.example.lenovo.lab31;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.animation.ScaleAnimation;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter;

public class MainActivity extends AppCompatActivity {
    private boolean flag=true;
    private List<Map<String,Object>> data_shop=new ArrayList<>();
    SimpleAdapter simpleAdapter;
    CommonAdapter commonAdapter;
    final String [] name={"Enchated Forest","Arla Milk","Devondale Milk","Kindle Oasis","waitrose 早餐麦片","Mcvitie's 饼干","Ferrero Rocher","Maltesers","Lindt","Borggreve"};
    final String []firstLetter={"E","A","D","K","w","M","F","M","L","B"};
    final String[] prices={"￥5.00","￥59.00","￥79.00","￥2399.00","￥179.00","￥14.90","￥132.59.00","￥141.43","￥139.43","￥28.90"};
    final String []tips={"作者 Johanna Basford","产地 德国","产地 澳大利亚","版本 8G","重量 2Kg","产地 英国","重量 300g","重量 118g","重量 249g","重量 640g"};
    //建立动态数组
    final ArrayList<String> prices_dynamic=new ArrayList<String>();
    final ArrayList<String> name_dynamic=new ArrayList<String>();
    final ArrayList<String> tips_dynamic=new ArrayList<String>();
    final ArrayList<String> first_dynamic=new ArrayList<String>();//前四个为商品列表的信息
        //重写activity回调函数
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            if(bundle!=null) {
                Map<String, Object> temp = new LinkedHashMap<>();
                temp.put("shop_first", bundle.getString("shop_first1"));
                temp.put("shop_name", bundle.getString("shop_name1"));
                temp.put("shop_price", bundle.getString("shop_price1"));
                data_shop.add(temp);
                simpleAdapter.notifyDataSetChanged();
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /************************商品列表*****************************/
        final RecyclerView mrecyclerview= findViewById(R.id.recycler_view);
        final ListView shopping_listview=findViewById(R.id.shop_items);
        shopping_listview.setVisibility(View.GONE);//购物车界面初始化不显示
        mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        for(int i=0;i<10;i++){
            prices_dynamic.add(prices[i]);//价格
            tips_dynamic.add(tips[i]);//价格底下的商品信息
            name_dynamic.add(name[i]);//名称
            first_dynamic.add(firstLetter[i]);//首字母
        }
        ArrayList<Map<String, Object>> list_data = new ArrayList<>();
        for(int i=0;i<10;i++) {
            Map<String, Object> map = new HashMap<>();
            map.put("firstLetter",firstLetter[i]);
            map.put("name",name[i]);
            list_data.add(map);
        }
       commonAdapter=new CommonAdapter(this,R.layout.goods_list_item,list_data) {
           @Override
           public void convert(ViewHolder holder, Map<String, Object> t) {
               TextView name = holder.getView(R.id.name);
               name.setText(t.get("name").toString());
               TextView first = holder.getView(R.id.firstLetter);
               first.setText(t.get("firstLetter").toString());
           }
       };
        ScaleInAnimationAdapter animationAdapter=new ScaleInAnimationAdapter(commonAdapter);
        animationAdapter.setDuration(1000);
        mrecyclerview.setAdapter(animationAdapter);
        mrecyclerview.setItemAnimator(new DefaultItemAnimator());
        /***************************对商品列表进行事件处理********************************/
        commonAdapter.setOnItemClickListener(new CommonAdapter.OnItemClickListener() {
            @Override
            public void onClick(final int position) {
                /****************点击商品，进入SecondActivity信息表*******************/
                Intent intent= new Intent(MainActivity.this,SecondActivity.class);
                Bundle b=new Bundle();//新建bundlle,将要传给secondActivity的数据打包
                b.putString("name_dynamic0",name_dynamic.get(position));
                b.putString("tips_dynamic0",tips_dynamic.get(position));
                b.putString("prices_dynamic0",prices_dynamic.get(position));
                b.putString("first_dynamic0",first_dynamic.get(position));
                b.putInt("position",position);
                intent.putExtras(b);//把数据包传给intent,由intent去传递数据
                startActivityForResult(intent,1);
                //注意：在新建activity时，不要忘了在manifest.xml里面添加新建activity的节点，否者容易出现闪退
            }
            /***长按删除第“position”个商品，出现消失动画**/
            @Override
            public void onLongClick(int position) {
                commonAdapter.removeData(position);
                Toast.makeText(MainActivity.this, "移除第"+position+"个商品", Toast.LENGTH_SHORT).show();
                name_dynamic.remove(position);//同时删除动态数组的相应数据
                first_dynamic.remove(position);
            }
        });
        /********************点击悬浮按钮，进行‘商品列表’和‘购物车’的界面切换***********************/
        final FloatingActionButton shop_cart=(FloatingActionButton) findViewById(R.id.fab);
        shop_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(flag==true) {;
                    mrecyclerview.setVisibility(View.GONE);//让商品列表界面消失，同时显示商品信息界面
                    shopping_listview.setVisibility(View.VISIBLE);
                    shop_cart.setImageResource(R.mipmap.mainpage);//切换图标
                }
                else {
                    shopping_listview.setVisibility(View.GONE);//让商品信息界面消失，同时显示商品列表界面
                    mrecyclerview.setVisibility(View.VISIBLE);
                    shop_cart.setImageResource(R.mipmap.shoplist);//切换图标
                }
                flag=!flag;
            }
        });
        /***********************************购物车界面***********************************************/
        Map<String, Object> temp = new LinkedHashMap<>();
        temp.put("shop_first","*");
        temp.put("shop_name", "购物车");
        temp.put("shop_price", "价格");
        data_shop.add(temp);
        simpleAdapter=new SimpleAdapter(this,data_shop,R.layout.shop_list,new String[]{"shop_first","shop_name","shop_price"},new int[]{R.id.shop_firstLetter,R.id.shop_name,R.id.shop_price});
        shopping_listview.setAdapter(simpleAdapter);
                     /********长按，移除购物车上的商品**********************/
        shopping_listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(final AdapterView<?> parent, View view, final int position, long id) {
            if(position>0){//第一行不执行按钮操作
                    int Real_position=0;
                    for(int i=0;i<10;i++){//找出真正的商品位置/商品列表的商品位置
                        Map<String, Object> temp = new LinkedHashMap<>();
                        temp.put("shop_first",first_dynamic.get(i));
                        temp.put("shop_name", name_dynamic.get(i));
                        temp.put("shop_price", prices_dynamic.get(i));
                        if(data_shop.get(position).equals(temp)) {
                            Real_position=i;
                            break;
                        }
                    }
                    AlertDialog.Builder alertDialog=new AlertDialog.Builder(MainActivity.this);
                    alertDialog.setTitle("移除商品").setMessage("从购物车移除"+name_dynamic.get(Real_position)).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    }).setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            data_shop.remove(position);
                            simpleAdapter.notifyDataSetChanged();
                        }
                    }).create();
                    alertDialog.show();
                }
                return true;//return true 说明执行长按操作，反之不执行
            }
        });
                /*******************点击，查看购买商品的信息**********/
        shopping_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position>0){//当点击第一行，或找不到商品位置时，不跳转界面
                    int Real_position=-1;
                    for(int i=0;i<10;i++){//找出真正的商品位置
                        Map<String, Object> temp = new LinkedHashMap<>();
                        temp.put("shop_first",first_dynamic.get(i));
                        temp.put("shop_name", name_dynamic.get(i));
                        temp.put("shop_price", prices_dynamic.get(i));
                        if(data_shop.get(position).equals(temp)){
                            Real_position=i;
                            break;
                        }
                    }
                    Intent intent= new Intent(MainActivity.this,SecondActivity.class);
                    Bundle b=new Bundle();//新建bundlle,将要传给secondActivity的数据打包
                    b.putInt("position",Real_position);
                    b.putString("name_dynamic0",name_dynamic.get(Real_position));
                    b.putString("tips_dynamic0",tips_dynamic.get(Real_position));
                    b.putString("prices_dynamic0",prices_dynamic.get(Real_position));
                    b.putString("first_dynamic0",first_dynamic.get(Real_position));
                    intent.putExtras(b);//把数据包传给intent,由intent去传递数据
                    startActivityForResult(intent,2);
                }
            }
        });
    }
}
