package com.example.lenovo.lab31;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class SecondActivity extends AppCompatActivity{
    private boolean flag2=true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_info);
        final Intent i=getIntent();
        final Bundle data=i.getExtras();//接收数据包的传送
        final String s1=data.getString("name_dynamic0"),s2=data.getString("prices_dynamic0"),s0=data.getString("first_dynamic0");
        final String[] operations={"一键下单","分享商品","不感兴趣","查看更多商品促销信息"};
        int[] ItemImage={R.mipmap.enchatedforest,R.mipmap.arla,R.mipmap.devondale,R.mipmap.kindle,R.mipmap.waitrose,R.mipmap.mcvitie,R.mipmap.ferrero,R.mipmap.maltesers,R.mipmap.lindt,R.mipmap.borggreve};
        //上述为十个图片的id
        TextView ItemName=findViewById(R.id.item_name);ItemName.setText(data.getString("name_dynamic0"));//设置物品名称
        TextView ItemPrice=findViewById(R.id.item_price);ItemPrice.setText(data.getString("prices_dynamic0"));//设置价格
        TextView ItemTips=findViewById(R.id.item_tip);ItemTips.setText(data.getString("tips_dynamic0"));//设置商品出产地
        ImageView mItemImage=findViewById(R.id.item_image);mItemImage.setImageResource(ItemImage[data.getInt("position")]);//设置图片
        /*********设置listview，显示四个操作********/
        ArrayList<Map<String, Object>> item_information_data = new ArrayList<>();
        for(int j=0;j<4;j++){
            Map<String, Object> map = new HashMap<>();
            map.put("operations",operations[j]);
            item_information_data.add(map);
        }
        final ListView item_info_listView=findViewById(R.id.itemlist_info);
        SimpleAdapter simpleAdapter1=new SimpleAdapter(this,item_information_data,R.layout.item_information,new String[]{"operations"},new int[]{R.id.item_operation});
        item_info_listView.setAdapter(simpleAdapter1);
        /*********************点击购物车图标***************************/
        ImageView cart= (ImageView)findViewById(R.id.cart);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SecondActivity.this, "商品已加到购物车", Toast.LENGTH_SHORT).show();
                Intent intent_return =new Intent();
                Bundle data_return=new Bundle();
                data_return.putString("shop_first1",s0);//添加要回传给mainActivity的数据
                data_return.putString("shop_name1",s1);
                data_return.putString("shop_price1",s2);
                intent_return.putExtras(data_return);//把数据包传给intent,由intent去传递数据
                setResult(RESULT_OK, intent_return);
            }
        });
        /******************点击星星图标*********************/
        final ImageView star=findViewById(R.id.star_state);
        star.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(flag2) star.setImageResource(R.mipmap.full_star);
                else star.setImageResource(R.mipmap.empty_star);
                flag2=!flag2;
            }
        });
        /********************返回键***********************/
        ImageView back_=findViewById(R.id.back);
        if(back_!=null) {
            back_.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();//返回上一个activity
                }
            });
        }
    }
}
